export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyAPTQkbwvK7FGgdknFAyONki4FVVHxG-Dw",
    authDomain: "liomreikimeditation.firebaseapp.com",
    databaseURL: "https://liomreikimeditation.firebaseio.com",
    projectId: "liomreikimeditation",
    storageBucket: "",
    messagingSenderId: "349926208077"
  }
};
