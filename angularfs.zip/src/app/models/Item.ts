export interface Item {
  id?:string;
  title?:string;
  content?: string;
}